import java.io.File;
import java.lang.reflect.Array;
import java.util.Arrays;

public class Pra1 {
    Pra1() {
        File f = new File("");
        System.out.println(f.getAbsolutePath());
        f = new File(f.getAbsolutePath());
        System.out.println(f.getName());
        System.out.println(Arrays.toString(f.list()));
        System.out.println(f.length());
    }
}
