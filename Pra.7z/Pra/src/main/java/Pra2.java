import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class Pra2 extends JFrame {
    private enum Unidades {
        BY("by"),KB("Kb"),MB("Mb"),GB("Gb"),TB("Tb"),PB("Pb");
        private String unidates;

        private Unidades(String unidates) {
            this.unidates = unidates;
        }
        public String tomaUnidates() {
            return unidates;
        }
    }
    public Pra2() {
        File[] unidades = File.listRoots();
        JPanel panel = new JPanel();
        JTextArea patalla = new JTextArea();
        String texts = String.format("%-10s%23s%23s\n" ,"Nombre", "Tamaño Total", "Tamaño disponible");
        patalla.setText(texts);;
        patalla.setForeground(Color.BLUE);
        this.setSize(700,700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Unidades");
        setUndecorated(true);
        panel.setBackground(Color.BLACK);
        panel.setLayout(null);
        patalla.setBounds(25,25,650,650);
        patalla.setEditable(false);
        patalla.setBackground(Color.DARK_GRAY);
        patalla.setBorder(null);
        for(File f : unidades){
            Unidades unidadesTotal;
            Unidades unidadesLibre;
            long unidadesTotalNumero = f.getTotalSpace();
            long unidadesLibreNumero = f.getFreeSpace();
            if (unidadesTotalNumero< 1024) {
                unidadesTotal = Unidades.BY;
            }else {
                unidadesTotalNumero /= 1024;
                if (unidadesTotalNumero< 1024) {
                    unidadesTotal = Unidades.KB;
                }else {
                    unidadesTotalNumero /= 1024;
                    if (unidadesTotalNumero< 1024) {
                        unidadesTotal = Unidades.MB;
                    }else {
                        unidadesTotalNumero /= 1024;
                        if (unidadesTotalNumero< 1024) {
                            unidadesTotal = Unidades.GB;
                        }else {
                            unidadesTotalNumero /= 1024;
                            if (unidadesTotalNumero< 1024) {
                                unidadesTotal = Unidades.TB;
                            }else {
                                unidadesTotalNumero /= 1024;
                                unidadesTotal = Unidades.PB;
                            }
                        }
                    }
                }
            }
            if (unidadesLibreNumero< 1024) {
                unidadesLibre = Unidades.BY;
            }else {
                unidadesLibreNumero /= 1024;
                if (unidadesLibreNumero< 1024) {
                    unidadesLibre = Unidades.KB;
                }else {
                    unidadesLibreNumero /= 1024;
                    if (unidadesLibreNumero< 1024) {
                        unidadesLibre = Unidades.MB;
                    }else {
                        unidadesLibreNumero /= 1024;
                        if (unidadesLibreNumero< 1024) {
                            unidadesLibre = Unidades.GB;
                        }else {
                            unidadesLibreNumero /= 1024;
                            if (unidadesLibreNumero< 1024) {
                                unidadesLibre = Unidades.TB;
                            }else {
                                unidadesLibreNumero /= 1024;
                                unidadesLibre = Unidades.PB;
                            }
                        }
                    }
                }
            }
            System.out.printf("%-10s%20s"+unidadesTotal.tomaUnidates()+"%20s"+unidadesLibre.tomaUnidates()+"\n",f,unidadesTotalNumero, unidadesLibreNumero);
            String outr = String.format("%-10s%20s"+unidadesTotal.tomaUnidates()+"%20s"+unidadesLibre.tomaUnidates()+"\n",f,unidadesTotalNumero, unidadesLibreNumero);
            patalla.append(outr);
            panel.add(patalla);
            add(panel);
            setVisible(true);
        }
    }
}
