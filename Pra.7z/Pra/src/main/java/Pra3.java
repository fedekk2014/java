public class Pra3 {
}
