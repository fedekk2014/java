public class Main {
    public static void main(String[] args) {
        //new Pra1();
        new Pra2();
    }
}
